<?php

// Make a MySQL Connection
$host="54.206.67.250";
$user="root";
$password="music";
$db = "users";

$link = mysqli_connect($host, $user, $password);
mysqli_select_db($link, $db) or die(mysql_error());

?>
