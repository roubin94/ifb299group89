<?php
$title = "Home";
$content = "Hello World";

include 'Template.php';

?>